# ClaudeThread

Slack에서 내 PC의 Claude Code를 쓰고 싶은 사람을 위한 도구.

`claude -p`를 직접 호출하는 얇은 레이어라서, Claude Code가 업데이트되면 별도 작업 없이 새 기능을 그대로 쓸 수 있다. openclaw 같은 풀 재구현이 부담스럽고, 그냥 Slack 스레드에서 멘션 한 번으로 Claude Code를 돌리고 싶다면 이쪽.

![ClaudeThread Settings](docs/images/config-gui.png)

설치 후 `localhost:3200`에서 설정 페이지가 열린다. Slack 토큰, Claude Code 경로, 인증 방식 등을 입력하면 바로 사용할 수 있다.

## 설정 항목

Slack: Bot Token, App Token (Socket Mode)

Claude Code: 바이너리 경로, 작업 디렉토리, 인증 방식 (OAuth / API Key)

Runner: 최대 동시 프로세스 수, Kill Timeout, Judgment Buffer Size, Judgment Interval
