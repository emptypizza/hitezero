# docs/ — Navigation Index

Project planning documents for ClaudeThread.

## Structure

- `overview.md` — Project-level vision, philosophy, competitive positioning, and phase roadmap
- `guard-rails.md` — Constraints and rules that apply across all features

## Feature Folders

Each folder contains `overview.md` (intent/experience) and `requirements.md` (testable rules).

- `slack-integration/` — Slack Socket Mode connection, mention detection, thread-based routing, real-time streaming
- `claude-runner/` — `claude -p` process spawn, stdout streaming, process lifecycle (start/kill), Windows compat
- `config-gui/` — Local web UI for settings (tokens, paths, auth method), validation, zero-restart config changes

## Planning Phase Reference

- Phase 1 (intent): `overview.md` per feature — user experience and design intent
- Phase 2 (rules): `requirements.md` per feature — testable rules derived from scenarios
- Phase 3 (impl spec): only on explicit request
