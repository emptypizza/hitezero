# ClaudeThread - 프로젝트 개요

## 비전

개발자가 Slack 스레드에서 Claude Code를 제어하고, 작업 진행 상황을 실시간으로 확인할 수 있는 도구.

로컬 머신에서 `claude -p`를 직접 호출하는 얇은 레이어로, Claude Code의 모든 업데이트를 자동으로 수혜받는다. API를 재구현하는 방식(openclaw 등)과 달리, Claude Code 바이너리 자체를 활용하므로 새로운 기능이 추가될 때마다 별도 작업 없이 즉시 반영된다.

## 핵심 경험

**Slack에서 멘션 한 번으로 Claude Code 작업이 시작된다.** 개발자는 IDE를 열지 않고도 Slack 스레드에서 작업 지시, 진행 확인, 중단을 할 수 있다. 각 스레드가 하나의 작업 단위이므로 맥락이 섞이지 않는다.

사용자가 느끼는 흐름:
1. Slack 채널에서 봇을 멘션하며 작업 지시
2. 봇이 해당 스레드에 실시간으로 Claude Code 출력을 스트리밍
3. 필요하면 스레드 내에서 추가 지시하거나, kill 명령으로 중단
4. 작업 완료 시 결과가 스레드에 정리되어 팀원 누구나 확인 가능

## 설계 철학

**얇은 오케스트레이션**: 이 도구는 Slack과 Claude Code 사이의 다리 역할만 한다. 복잡한 프롬프트 엔지니어링이나 하네스 로직은 대상 레포지토리의 CLAUDE.md에 위임한다. ClaudeThread 자체는 메시지 라우팅과 프로세스 관리에 집중한다.

**Claude Code 네이티브**: `claude -p` 커맨드를 직접 호출한다. 이는 Anthropic이 Claude Code에 추가하는 모든 기능(도구 사용, MCP, 컨텍스트 관리 등)을 자동으로 활용할 수 있음을 의미한다.

**Slack-first UI**: 별도 대시보드를 만들지 않는다. Slack 스레드가 작업의 시작점이자 모니터링 화면이다. 설정만 간단한 웹 GUI로 제공한다.

## 대상 사용자

Claude Code를 팀 환경에서 활용하고 싶은 개발자. 특히 Slack을 주 커뮤니케이션 도구로 사용하며, 로컬 머신에서 Claude Code가 이미 동작하는 환경을 가진 팀.

## 경쟁 포지셔닝

- **openclaw**: Claude API 직접 호출 방식으로 Claude Code 기능을 재구현해야 함. ClaudeThread는 `claude -p` 호출로 모든 기능 자동 수혜
- **Claude-Code-Agent-Monitor**: 모니터링 전용, 트리거 기능 없음. ClaudeThread는 제어까지 포함
- **Paperclip**: 풀 오케스트레이션 플랫폼으로 무거움. ClaudeThread는 경량 레이어

## Phase 로드맵

### Phase 1 (MVP)

Slack에서 Claude Code를 실행하고 결과를 볼 수 있는 최소 기능.

기능 영역: slack-integration, claude-runner, config-gui

### Phase 2

병렬 작업과 비용 관리. git worktree 기반으로 여러 작업을 동시 수행하고, 토큰/비용 사용량을 추적한다.

### Phase 3

운영 안정성. OTEL 기반 추적, 루프/재시도 오케스트레이션, 멀티 노드 지원.

## 제약 조건

- Windows 환경 우선 지원
- Docker 없이 동작 (일반 사용자 기준)
- Claude Code OAuth 토큰 및 API 키 둘 다 지원
- Node.js 런타임, Slack Bolt SDK (Socket Mode)
