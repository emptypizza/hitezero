# ClaudeThread

Slack thread-driven control layer for Claude Code. Calls `claude -p` directly — no API reimplementation.

## Architecture

- **Thin orchestration**: Slack message in -> `claude -p` subprocess -> stdout streamed back to Slack thread
- **Socket Mode**: Slack Bolt SDK with Socket Mode. No server, no port, no ingress
- **1 thread = 1 task**: Each Slack thread maps to one Claude Code execution context
- **CLAUDE.md delegation**: Complex harness logic belongs in CLAUDE.md files within target repos, not in this tool

## Tech Stack

- Runtime: Node.js
- Slack: @slack/bolt (Socket Mode)
- Process: child_process spawn for `claude -p`

## Project Structure

```
src/           # Application source
docs/          # Planning documents (feature-based folders)
  slack-integration/   # Slack Socket Mode, mention detection, thread mapping
  claude-runner/       # claude -p execution, streaming, process lifecycle
  config-gui/          # Web-based settings UI
```

## Coding Conventions

- Language: TypeScript (strict mode)
- Module system: ESM
- Naming: camelCase for variables/functions, PascalCase for types/classes, kebab-case for files
- Error handling: explicit error types, no silent catches
- Comments: English

## Defaults

- Claude Code auth: Google OAuth (customizable)
- Project repo: GitHub (customizable)
- Channel-node binding: one Slack channel = one PC node

## Key Constraints

- Windows-first (no Docker dependency)
- Support both OAuth token and API key auth for Claude Code
- Slack thread = unit of work (strict 1:1 mapping)
- Multiple PC nodes supported; each node binds to a Slack channel

## Phase Roadmap

- Phase 1 (MVP): Slack connection + claude -p execution + process kill + config GUI
- Phase 2: git worktree parallel tasks, per-thread mapping, cost/token alerts
- Phase 3: OTEL tracing, loop/retry orchestration, multi-node

## Planning Docs

Feature-level planning lives in `docs/{feature}/`. Each feature folder contains:
- `overview.md` — intent and user experience (Phase 1 planning)
- `requirements.md` — testable rules from scenarios (Phase 2 planning)

Read the relevant feature docs before implementing.
