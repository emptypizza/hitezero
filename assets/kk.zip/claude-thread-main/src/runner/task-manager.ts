// Task lifecycle manager: spawn, queue, track, kill
// Owns the claude -p subprocess and LLM judgment loop

import { spawn, type ChildProcess } from "node:child_process";
import { EventEmitter } from "node:events";
import type { AppConfig, TaskRecord, ProcessState, JudgmentResult } from "../types.js";
import { judge } from "./judgment.js";
import { killProcess } from "./process-killer.js";

interface TaskEvents {
  judgment: [threadId: string, result: JudgmentResult];
  stateChange: [threadId: string, state: ProcessState];
}

export class TaskManager extends EventEmitter<TaskEvents> {
  private tasks = new Map<string, TaskRecord>();
  private processes = new Map<string, ChildProcess>();
  private judgmentTimers = new Map<string, ReturnType<typeof setInterval>>();
  private queue: string[] = []; // threadIds waiting to run
  private config: AppConfig;

  constructor(config: AppConfig) {
    super();
    this.config = config;
  }

  updateConfig(config: AppConfig): void {
    this.config = config;
  }

  /** Submit a new task. Starts immediately or queues if at capacity. */
  submit(threadId: string, channelId: string, prompt: string): TaskRecord {
    if (this.tasks.has(threadId)) {
      return this.tasks.get(threadId)!;
    }

    const task: TaskRecord = {
      threadId,
      channelId,
      pid: null,
      state: "queued",
      prompt,
      startedAt: null,
      endedAt: null,
      stdoutBuffer: "",
      stderrBuffer: "",
    };

    this.tasks.set(threadId, task);

    if (this.runningCount() < this.config.runner.maxConcurrent) {
      this.start(threadId);
    } else {
      this.queue.push(threadId);
    }

    return task;
  }

  /** Get task by thread ID */
  getTask(threadId: string): TaskRecord | undefined {
    return this.tasks.get(threadId);
  }

  /** Count of running + queued */
  status(): { running: number; queued: number } {
    return {
      running: this.runningCount(),
      queued: this.queue.length,
    };
  }

  /** Queue position (1-based), or 0 if not queued */
  queuePosition(threadId: string): number {
    const idx = this.queue.indexOf(threadId);
    return idx === -1 ? 0 : idx + 1;
  }

  /** Kill task in a specific thread */
  async kill(threadId: string): Promise<boolean> {
    const task = this.tasks.get(threadId);
    if (!task || task.state !== "running") return false;

    const child = this.processes.get(threadId);
    if (!child || child.pid === undefined) return false;

    this.stopJudgmentLoop(threadId);
    await killProcess(child.pid, this.config.runner.killTimeoutMs);
    this.transition(threadId, "killed");
    return true;
  }

  /** Kill all running tasks and drain queue */
  async meltdown(): Promise<number> {
    let killed = 0;

    // Kill running
    const runningIds = [...this.tasks.entries()]
      .filter(([, t]) => t.state === "running")
      .map(([id]) => id);

    for (const id of runningIds) {
      if (await this.kill(id)) killed++;
    }

    // Drain queue
    const queuedCount = this.queue.length;
    for (const id of this.queue) {
      this.transition(id, "killed");
    }
    this.queue = [];

    return killed + queuedCount;
  }

  // --- Internal ---

  private runningCount(): number {
    let count = 0;
    for (const t of this.tasks.values()) {
      if (t.state === "running") count++;
    }
    return count;
  }

  private start(threadId: string): void {
    const task = this.tasks.get(threadId);
    if (!task) return;

    const bin = this.config.claude.binaryPath || "claude";
    const cwd = this.config.claude.workingDirectory || process.cwd();

    const env: Record<string, string> = { ...process.env as Record<string, string> };
    if (this.config.claude.authMethod === "apikey" && this.config.claude.apiKey) {
      env.ANTHROPIC_API_KEY = this.config.claude.apiKey;
    }

    const child = spawn(bin, ["-p"], {
      cwd,
      env,
      stdio: ["pipe", "pipe", "pipe"],
    });

    this.processes.set(threadId, child);
    task.pid = child.pid ?? null;
    task.startedAt = new Date();
    this.transition(threadId, "running");

    // Collect stdout
    child.stdout.on("data", (chunk: Buffer) => {
      task.stdoutBuffer += chunk.toString();
    });

    // Collect stderr
    child.stderr.on("data", (chunk: Buffer) => {
      task.stderrBuffer += chunk.toString();
    });

    // Process exit
    child.on("close", (code, signal) => {
      this.stopJudgmentLoop(threadId);
      task.endedAt = new Date();

      if (task.state as string === "killed") {
        // Already handled by kill()
      } else if (code === 0) {
        // Run final judgment on complete output
        this.runJudgment(threadId).then(() => {
          if (task.state === "running") {
            this.transition(threadId, "completed");
          }
        });
      } else if (signal && task.state !== "killed") {
        this.transition(threadId, "failed");
        this.emit("judgment", threadId, {
          category: "failed",
          summary: `Process terminated by signal: ${signal}`,
        });
      } else {
        this.transition(threadId, "failed");
        // Run judgment to get error summary
        this.runJudgment(threadId);
      }

      this.processes.delete(threadId);
      this.dequeue();
    });

    child.on("error", (err) => {
      this.stopJudgmentLoop(threadId);
      task.endedAt = new Date();
      this.transition(threadId, "failed");
      this.emit("judgment", threadId, {
        category: "failed",
        summary: `Process spawn error: ${err.message}`,
      });
      this.processes.delete(threadId);
      this.dequeue();
    });

    // Write prompt to stdin
    child.stdin.write(task.prompt);
    child.stdin.end();

    // Start periodic judgment
    this.startJudgmentLoop(threadId);
  }

  private startJudgmentLoop(threadId: string): void {
    const { judgmentIntervalMs, judgmentBufferSize } = this.config.runner;

    const timer = setInterval(async () => {
      const task = this.tasks.get(threadId);
      if (!task || task.state !== "running") {
        this.stopJudgmentLoop(threadId);
        return;
      }

      // Only judge if buffer has enough content
      if (task.stdoutBuffer.length < judgmentBufferSize) return;

      await this.runJudgment(threadId);
    }, judgmentIntervalMs);

    this.judgmentTimers.set(threadId, timer);
  }

  private stopJudgmentLoop(threadId: string): void {
    const timer = this.judgmentTimers.get(threadId);
    if (timer) {
      clearInterval(timer);
      this.judgmentTimers.delete(threadId);
    }
  }

  private async runJudgment(threadId: string): Promise<void> {
    const task = this.tasks.get(threadId);
    if (!task) return;

    const result = await judge(
      task.stdoutBuffer,
      task.stderrBuffer,
      this.config.claude.binaryPath,
    );

    if (result.category === "in_progress") return;

    this.emit("judgment", threadId, result);

    // Auto-transition on terminal states from judgment
    if (result.category === "completed") {
      this.transition(threadId, "completed");
    } else if (result.category === "failed") {
      this.transition(threadId, "failed");
    }
  }

  private transition(threadId: string, newState: ProcessState): void {
    const task = this.tasks.get(threadId);
    if (!task) return;
    task.state = newState;
    if (["completed", "failed", "killed"].includes(newState)) {
      task.endedAt = task.endedAt ?? new Date();
    }
    this.emit("stateChange", threadId, newState);
  }

  private dequeue(): void {
    if (this.queue.length === 0) return;
    if (this.runningCount() >= this.config.runner.maxConcurrent) return;

    const nextId = this.queue.shift()!;
    this.start(nextId);
  }
}
