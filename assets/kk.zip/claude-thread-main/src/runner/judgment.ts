// LLM judgment layer using claude -p
// Analyzes stdout buffer and classifies task state

import { spawn } from "node:child_process";
import type { JudgmentResult } from "../types.js";

const JUDGMENT_PROMPT = `You are a task status judge. Analyze the following Claude Code output and respond with ONLY a JSON object (no markdown, no explanation).

Classify into exactly one category:
- "completed": Task finished successfully with clear result
- "failed": Task encountered an error or cannot proceed
- "user_confirmation_needed": Task requires user decision (dangerous operation, ambiguous instruction, or choice needed)
- "loop_detected": Output shows repetitive patterns indicating a stuck loop
- "in_progress": Task is still working normally

JSON format:
{"category": "<category>", "summary": "<1-2 sentence summary for Slack>", "options": ["option1", "option2"]}
"options" field is required only for "user_confirmation_needed".

--- Claude Code Output ---
`;

export async function judge(
  stdout: string,
  stderr: string,
  binaryPath: string,
): Promise<JudgmentResult> {
  const input = buildInput(stdout, stderr);

  try {
    const raw = await runClaudeP(binaryPath, input);
    return parseJudgment(raw);
  } catch (error) {
    // If judgment itself fails, treat as in_progress to avoid false alerts
    console.error("[judgment] LLM call failed:", error);
    return { category: "in_progress", summary: "" };
  }
}

function buildInput(stdout: string, stderr: string): string {
  let input = JUDGMENT_PROMPT + stdout;
  if (stderr) {
    input += "\n--- stderr ---\n" + stderr;
  }
  return input;
}

function runClaudeP(binaryPath: string, input: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const bin = binaryPath || "claude";
    const child = spawn(bin, ["-p"], {
      stdio: ["pipe", "pipe", "pipe"],
    });

    let output = "";
    let error = "";

    child.stdout.on("data", (chunk: Buffer) => {
      output += chunk.toString();
    });
    child.stderr.on("data", (chunk: Buffer) => {
      error += chunk.toString();
    });

    child.on("close", (code) => {
      if (code === 0) {
        resolve(output.trim());
      } else {
        reject(new Error(`claude -p exited with code ${code}: ${error}`));
      }
    });

    child.on("error", (err) => {
      reject(err);
    });

    child.stdin.write(input);
    child.stdin.end();
  });
}

function parseJudgment(raw: string): JudgmentResult {
  // Extract JSON from response (may contain markdown fences)
  const jsonMatch = raw.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    console.warn("[judgment] No JSON found in response, defaulting to in_progress");
    return { category: "in_progress", summary: "" };
  }

  try {
    const parsed = JSON.parse(jsonMatch[0]);
    const validCategories = [
      "user_confirmation_needed",
      "completed",
      "failed",
      "loop_detected",
      "in_progress",
    ];

    if (!validCategories.includes(parsed.category)) {
      return { category: "in_progress", summary: parsed.summary ?? "" };
    }

    return {
      category: parsed.category,
      summary: parsed.summary ?? "",
      options: parsed.options,
    };
  } catch {
    console.warn("[judgment] Failed to parse JSON, defaulting to in_progress");
    return { category: "in_progress", summary: "" };
  }
}
