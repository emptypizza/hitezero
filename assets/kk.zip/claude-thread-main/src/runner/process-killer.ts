// OS-aware process termination
// Windows: taskkill /T /F /PID (tree kill, immediate)
// Unix: SIGTERM -> timeout -> SIGKILL

import { exec } from "node:child_process";
import { platform } from "node:process";

export function killProcess(pid: number, timeoutMs: number): Promise<void> {
  if (platform === "win32") {
    return killWindows(pid);
  }
  return killUnix(pid, timeoutMs);
}

function killWindows(pid: number): Promise<void> {
  return new Promise((resolve, reject) => {
    exec(`taskkill /T /F /PID ${pid}`, (error) => {
      if (error) {
        // Process may already be dead
        if (error.message.includes("not found")) {
          resolve();
        } else {
          reject(error);
        }
      } else {
        resolve();
      }
    });
  });
}

function killUnix(pid: number, timeoutMs: number): Promise<void> {
  return new Promise((resolve) => {
    try {
      process.kill(pid, "SIGTERM");
    } catch {
      // Already dead
      resolve();
      return;
    }

    const timer = setTimeout(() => {
      try {
        process.kill(pid, "SIGKILL");
      } catch {
        // Already dead
      }
      resolve();
    }, timeoutMs);

    // Poll to see if process exited after SIGTERM
    const check = setInterval(() => {
      try {
        // signal 0 checks if process exists
        process.kill(pid, 0);
      } catch {
        clearInterval(check);
        clearTimeout(timer);
        resolve();
      }
    }, 200);
  });
}
