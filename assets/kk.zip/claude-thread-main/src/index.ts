// ClaudeThread entry point
// Wires config, runner, slack, and GUI together

import { resolve } from "node:path";
import { ConfigStore } from "./config/config-store.js";
import { TaskManager } from "./runner/task-manager.js";
import { SlackService } from "./slack/slack-service.js";
import { ConfigGui } from "./gui/config-gui.js";

async function main(): Promise<void> {
  console.log("ClaudeThread starting...");

  // 1. Load config
  const configPath = resolve(process.env.CT_CONFIG ?? "config.json");
  const configStore = new ConfigStore(configPath);
  const config = configStore.get();

  // 2. Validate
  const errors = configStore.validate();
  if (errors.length > 0) {
    console.warn("[init] Config validation warnings:");
    for (const e of errors) console.warn(`  - ${e}`);
  }

  // 3. Start Config GUI (always — so user can fix config via browser)
  const gui = new ConfigGui(configStore, config.gui.port);
  await gui.start();

  // 4. Check if Slack tokens are present
  if (!config.slack.botToken || !config.slack.appToken) {
    console.log(
      `[init] Slack tokens missing. Configure via http://127.0.0.1:${config.gui.port}`,
    );
    console.log("[init] Waiting for config update...");

    // Wait for valid Slack config
    await waitForValidSlackConfig(configStore);
  }

  // 5. Start runner + Slack
  const taskManager = new TaskManager(configStore.get());
  const slack = new SlackService(configStore.get(), taskManager);

  await slack.start();
  console.log("ClaudeThread ready.");

  // 6. React to config changes at runtime
  configStore.on("change", async (newConfig, previousConfig) => {
    taskManager.updateConfig(newConfig);

    // Reconnect Slack if tokens changed
    if (
      newConfig.slack.botToken !== previousConfig.slack.botToken ||
      newConfig.slack.appToken !== previousConfig.slack.appToken
    ) {
      console.log("[config] Slack tokens changed, reconnecting...");
      await slack.reconnect(newConfig);
    }
  });

  // 7. Graceful shutdown
  const shutdown = async () => {
    console.log("\nShutting down...");
    await taskManager.meltdown();
    await slack.stop();
    await gui.stop();
    process.exit(0);
  };

  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

function waitForValidSlackConfig(
  configStore: ConfigStore,
): Promise<void> {
  return new Promise((resolve) => {
    // Check if already valid
    const errors = configStore.validate();
    const slackErrors = errors.filter(
      (e) => e.includes("Slack"),
    );
    if (slackErrors.length === 0) {
      resolve();
      return;
    }

    const handler = () => {
      const newErrors = configStore.validate();
      const remaining = newErrors.filter((e) => e.includes("Slack"));
      if (remaining.length === 0) {
        configStore.removeListener("change", handler);
        resolve();
      }
    };

    configStore.on("change", handler);
  });
}

main().catch((err) => {
  console.error("Fatal error:", err);
  process.exit(1);
});
