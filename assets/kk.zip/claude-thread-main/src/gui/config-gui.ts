// Localhost-only config GUI server
// Serves a simple HTML form for editing config.json

import { createServer, type Server } from "node:http";
import type { ConfigStore } from "../config/config-store.js";

export class ConfigGui {
  private server: Server | null = null;
  private configStore: ConfigStore;
  private port: number;

  constructor(configStore: ConfigStore, port: number) {
    this.configStore = configStore;
    this.port = port;
  }

  start(): Promise<void> {
    return new Promise((resolve) => {
      this.server = createServer((req, res) => {
        this.handleRequest(req, res);
      });

      // Bind to localhost only
      this.server.listen(this.port, "127.0.0.1", () => {
        console.log(`[gui] Config UI: http://127.0.0.1:${this.port}`);
        resolve();
      });
    });
  }

  stop(): Promise<void> {
    return new Promise((resolve) => {
      if (this.server) {
        this.server.close(() => resolve());
      } else {
        resolve();
      }
    });
  }

  private handleRequest(
    req: import("node:http").IncomingMessage,
    res: import("node:http").ServerResponse,
  ): void {
    const url = new URL(req.url ?? "/", `http://${req.headers.host}`);

    if (url.pathname === "/api/config" && req.method === "GET") {
      this.handleGetConfig(res);
    } else if (url.pathname === "/api/config" && req.method === "POST") {
      this.handlePostConfig(req, res);
    } else if (url.pathname === "/api/validate" && req.method === "GET") {
      this.handleValidate(res);
    } else if (url.pathname === "/" || url.pathname === "/index.html") {
      this.servePage(res);
    } else {
      res.writeHead(404);
      res.end("Not found");
    }
  }

  private handleGetConfig(res: import("node:http").ServerResponse): void {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(this.configStore.get()));
  }

  private handlePostConfig(
    req: import("node:http").IncomingMessage,
    res: import("node:http").ServerResponse,
  ): void {
    let body = "";
    req.on("data", (chunk: Buffer) => {
      body += chunk.toString();
    });
    req.on("end", () => {
      try {
        const patch = JSON.parse(body);
        this.configStore.update(patch);
        const errors = this.configStore.validate();
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: true, errors }));
      } catch (err) {
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: false, error: String(err) }));
      }
    });
  }

  private handleValidate(res: import("node:http").ServerResponse): void {
    const errors = this.configStore.validate();
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ valid: errors.length === 0, errors }));
  }

  private servePage(res: import("node:http").ServerResponse): void {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(CONFIG_PAGE_HTML);
  }
}

const CONFIG_PAGE_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ClaudeThread Settings</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: system-ui, sans-serif; max-width: 640px; margin: 2rem auto; padding: 0 1rem; color: #1a1a1a; }
  h1 { font-size: 1.4rem; margin-bottom: 1.5rem; }
  fieldset { border: 1px solid #ddd; border-radius: 8px; padding: 1rem; margin-bottom: 1rem; }
  legend { font-weight: 600; padding: 0 0.5rem; }
  label { display: block; margin: 0.5rem 0 0.2rem; font-size: 0.85rem; color: #555; }
  input, select { width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px; font-size: 0.9rem; }
  input:focus, select:focus { outline: none; border-color: #4a9eff; }
  .actions { margin-top: 1.5rem; display: flex; gap: 0.5rem; }
  button { padding: 0.6rem 1.2rem; border: none; border-radius: 4px; font-size: 0.9rem; cursor: pointer; }
  .btn-primary { background: #4a9eff; color: white; }
  .btn-primary:hover { background: #3a8eef; }
  .btn-secondary { background: #eee; }
  .errors { color: #d32f2f; font-size: 0.85rem; margin-top: 0.5rem; }
  .success { color: #2e7d32; font-size: 0.85rem; margin-top: 0.5rem; }
  .status { min-height: 1.5rem; margin-top: 0.5rem; }
</style>
</head>
<body>
<h1>ClaudeThread Settings</h1>
<form id="configForm">
  <fieldset>
    <legend>Slack</legend>
    <label for="botToken">Bot Token</label>
    <input id="botToken" type="password" placeholder="xoxb-...">
    <label for="appToken">App Token</label>
    <input id="appToken" type="password" placeholder="xapp-...">
  </fieldset>

  <fieldset>
    <legend>Claude Code</legend>
    <label for="binaryPath">Binary Path (empty = system PATH)</label>
    <input id="binaryPath" placeholder="/usr/local/bin/claude">
    <label for="workingDirectory">Working Directory (empty = current)</label>
    <input id="workingDirectory" placeholder="/home/user/project">
    <label for="authMethod">Auth Method</label>
    <select id="authMethod">
      <option value="oauth">OAuth</option>
      <option value="apikey">API Key</option>
    </select>
    <label for="apiKey">API Key (if API Key auth)</label>
    <input id="apiKey" type="password" placeholder="sk-ant-...">
  </fieldset>

  <fieldset>
    <legend>Runner</legend>
    <label for="maxConcurrent">Max Concurrent Processes</label>
    <input id="maxConcurrent" type="number" min="1" max="10">
    <label for="killTimeoutMs">Kill Timeout (ms)</label>
    <input id="killTimeoutMs" type="number" min="1000">
    <label for="judgmentBufferSize">Judgment Buffer Size (chars)</label>
    <input id="judgmentBufferSize" type="number" min="500">
    <label for="judgmentIntervalMs">Judgment Interval (ms)</label>
    <input id="judgmentIntervalMs" type="number" min="5000">
  </fieldset>

  <fieldset>
    <legend>GUI</legend>
    <label for="guiPort">Port</label>
    <input id="guiPort" type="number" min="1024" max="65535">
  </fieldset>

  <div class="actions">
    <button type="submit" class="btn-primary">Save</button>
    <button type="button" class="btn-secondary" onclick="loadConfig()">Reload</button>
  </div>
  <div id="status" class="status"></div>
</form>

<script>
async function loadConfig() {
  const res = await fetch('/api/config');
  const c = await res.json();
  document.getElementById('botToken').value = c.slack.botToken;
  document.getElementById('appToken').value = c.slack.appToken;
  document.getElementById('binaryPath').value = c.claude.binaryPath;
  document.getElementById('workingDirectory').value = c.claude.workingDirectory;
  document.getElementById('authMethod').value = c.claude.authMethod;
  document.getElementById('apiKey').value = c.claude.apiKey;
  document.getElementById('maxConcurrent').value = c.runner.maxConcurrent;
  document.getElementById('killTimeoutMs').value = c.runner.killTimeoutMs;
  document.getElementById('judgmentBufferSize').value = c.runner.judgmentBufferSize;
  document.getElementById('judgmentIntervalMs').value = c.runner.judgmentIntervalMs;
  document.getElementById('guiPort').value = c.gui.port;
}

document.getElementById('configForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const config = {
    slack: {
      botToken: document.getElementById('botToken').value,
      appToken: document.getElementById('appToken').value,
    },
    claude: {
      binaryPath: document.getElementById('binaryPath').value,
      workingDirectory: document.getElementById('workingDirectory').value,
      authMethod: document.getElementById('authMethod').value,
      apiKey: document.getElementById('apiKey').value,
    },
    runner: {
      maxConcurrent: Number(document.getElementById('maxConcurrent').value),
      killTimeoutMs: Number(document.getElementById('killTimeoutMs').value),
      judgmentBufferSize: Number(document.getElementById('judgmentBufferSize').value),
      judgmentIntervalMs: Number(document.getElementById('judgmentIntervalMs').value),
    },
    gui: {
      port: Number(document.getElementById('guiPort').value),
    },
  };

  const res = await fetch('/api/config', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config),
  });
  const result = await res.json();
  const el = document.getElementById('status');
  if (result.ok && result.errors.length === 0) {
    el.className = 'status success';
    el.textContent = 'Saved.';
  } else {
    el.className = 'status errors';
    el.textContent = (result.errors || [result.error]).join(', ');
  }
  setTimeout(() => { el.textContent = ''; }, 4000);
});

loadConfig();
</script>
</body>
</html>`;
