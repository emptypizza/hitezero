// File-backed JSON config store with runtime reload support

import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { EventEmitter } from "node:events";
import type { AppConfig } from "../types.js";

const DEFAULT_CONFIG: AppConfig = {
  slack: {
    botToken: "",
    appToken: "",
  },
  claude: {
    binaryPath: "",
    workingDirectory: "",
    authMethod: "oauth",
    apiKey: "",
  },
  runner: {
    maxConcurrent: 3,
    killTimeoutMs: 5000,
    judgmentBufferSize: 4000,
    judgmentIntervalMs: 10000,
  },
  gui: {
    port: 3200,
  },
};

export class ConfigStore extends EventEmitter {
  private config: AppConfig;
  private filePath: string;

  constructor(filePath?: string) {
    super();
    this.filePath = filePath ?? resolve("config.json");
    this.config = this.load();
  }

  private load(): AppConfig {
    if (!existsSync(this.filePath)) {
      return structuredClone(DEFAULT_CONFIG);
    }
    try {
      const raw = readFileSync(this.filePath, "utf-8");
      const parsed = JSON.parse(raw) as Partial<AppConfig>;
      return this.merge(DEFAULT_CONFIG, parsed);
    } catch {
      console.warn(`[config] Failed to parse ${this.filePath}, using defaults`);
      return structuredClone(DEFAULT_CONFIG);
    }
  }

  /** Deep merge defaults with user overrides */
  private merge(defaults: AppConfig, overrides: Partial<AppConfig>): AppConfig {
    const result = structuredClone(defaults);
    for (const section of Object.keys(defaults) as (keyof AppConfig)[]) {
      if (overrides[section] && typeof overrides[section] === "object") {
        Object.assign(result[section], overrides[section]);
      }
    }
    return result;
  }

  get(): AppConfig {
    return this.config;
  }

  /** Update config partially and persist to disk */
  update(patch: Partial<AppConfig>): void {
    const previous = structuredClone(this.config);
    this.config = this.merge(this.config, patch);
    this.save();
    this.emit("change", this.config, previous);
  }

  /** Reload config from disk (for external edits) */
  reload(): void {
    const previous = structuredClone(this.config);
    this.config = this.load();
    this.emit("change", this.config, previous);
  }

  private save(): void {
    const dir = dirname(this.filePath);
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }
    writeFileSync(this.filePath, JSON.stringify(this.config, null, 2), "utf-8");
  }

  /** Validate required fields; returns list of error messages */
  validate(): string[] {
    const errors: string[] = [];
    const c = this.config;

    if (!c.slack.botToken) {
      errors.push("Slack Bot Token is required");
    } else if (!c.slack.botToken.startsWith("xoxb-")) {
      errors.push("Slack Bot Token must start with xoxb-");
    }

    if (!c.slack.appToken) {
      errors.push("Slack App Token is required");
    } else if (!c.slack.appToken.startsWith("xapp-")) {
      errors.push("Slack App Token must start with xapp-");
    }

    if (c.claude.binaryPath && !existsSync(c.claude.binaryPath)) {
      errors.push(`Claude binary not found at: ${c.claude.binaryPath}`);
    }

    if (c.claude.workingDirectory && !existsSync(c.claude.workingDirectory)) {
      errors.push(
        `Working directory not found: ${c.claude.workingDirectory}`,
      );
    }

    if (c.runner.maxConcurrent < 1) {
      errors.push("Max concurrent must be >= 1");
    }

    return errors;
  }
}
