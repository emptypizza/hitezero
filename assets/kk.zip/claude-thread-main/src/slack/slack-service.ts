// Slack service: manages Bolt app lifecycle and provides posting utilities

import { App } from "@slack/bolt";
import type { AppConfig } from "../types.js";
import type { TaskManager } from "../runner/task-manager.js";
import { registerSlackHandlers } from "./message-router.js";

const REACTIONS = {
  received: "eyes",
  running: "hourglass_flowing_sand",
  completed: "white_check_mark",
  failed: "x",
  killed: "octagonal_sign",
} as const;

export class SlackService {
  private app: App | null = null;
  private taskManager: TaskManager;
  private config: AppConfig;

  constructor(config: AppConfig, taskManager: TaskManager) {
    this.config = config;
    this.taskManager = taskManager;
  }

  async start(): Promise<void> {
    this.app = new App({
      token: this.config.slack.botToken,
      appToken: this.config.slack.appToken,
      socketMode: true,
    });

    registerSlackHandlers(this.app, this.taskManager);
    this.wireEvents();

    await this.app.start();
    console.log("[slack] Connected via Socket Mode");
  }

  async stop(): Promise<void> {
    if (this.app) {
      await this.app.stop();
      this.app = null;
      console.log("[slack] Disconnected");
    }
  }

  /** Reconnect with new config (e.g., token change) */
  async reconnect(config: AppConfig): Promise<void> {
    this.config = config;
    await this.stop();
    await this.start();
  }

  /** Post a message to a thread */
  async postToThread(
    channel: string,
    threadTs: string,
    text: string,
  ): Promise<void> {
    if (!this.app) return;

    // Split long messages
    const chunks = splitMessage(text, 4000);
    for (const chunk of chunks) {
      await this.app.client.chat.postMessage({
        channel,
        thread_ts: threadTs,
        text: chunk,
      });
    }
  }

  /** Swap reaction on a message */
  async setReaction(
    channel: string,
    messageTs: string,
    reactionName: string,
  ): Promise<void> {
    if (!this.app) return;

    // Remove all known reactions first
    for (const name of Object.values(REACTIONS)) {
      try {
        await this.app.client.reactions.remove({
          channel,
          timestamp: messageTs,
          name,
        });
      } catch {
        // Not present, ignore
      }
    }

    try {
      await this.app.client.reactions.add({
        channel,
        timestamp: messageTs,
        name: reactionName,
      });
    } catch {
      // Non-critical
    }
  }

  /** Wire TaskManager events to Slack messages */
  private wireEvents(): void {
    this.taskManager.on("judgment", async (threadId, result) => {
      const task = this.taskManager.getTask(threadId);
      if (!task || !result.summary) return;

      let message = result.summary;

      if (
        result.category === "user_confirmation_needed" &&
        result.options
      ) {
        message +=
          "\n\n" +
          result.options.map((o, i) => `${i + 1}. ${o}`).join("\n");
      }

      if (result.category === "failed") {
        message += "\n\nRetry?";
      }

      await this.postToThread(task.channelId, threadId, message);
    });

    this.taskManager.on("stateChange", async (threadId, state) => {
      const task = this.taskManager.getTask(threadId);
      if (!task) return;

      const reactionMap: Record<string, string> = {
        running: REACTIONS.running,
        completed: REACTIONS.completed,
        failed: REACTIONS.failed,
        killed: REACTIONS.killed,
      };

      const reaction = reactionMap[state];
      if (reaction) {
        // We use threadId as messageTs for top-level messages
        // For thread replies, the original message ts would be needed
        // Phase 1: use threadTs as approximation
        await this.setReaction(task.channelId, threadId, reaction);
      }
    });
  }
}

function splitMessage(text: string, maxLen: number): string[] {
  if (text.length <= maxLen) return [text];

  const chunks: string[] = [];
  let remaining = text;
  while (remaining.length > 0) {
    if (remaining.length <= maxLen) {
      chunks.push(remaining);
      break;
    }
    // Find last newline within limit
    let splitAt = remaining.lastIndexOf("\n", maxLen);
    if (splitAt === -1 || splitAt < maxLen / 2) {
      splitAt = maxLen;
    }
    chunks.push(remaining.slice(0, splitAt));
    remaining = remaining.slice(splitAt).trimStart();
  }
  return chunks;
}
