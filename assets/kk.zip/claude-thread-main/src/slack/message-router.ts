// Slack message routing: mention detection, command parsing, thread mapping

import type { App, SayFn } from "@slack/bolt";
import type { TaskManager } from "../runner/task-manager.js";
import type { JudgmentResult } from "../types.js";

// Reaction emoji for each state
const REACTIONS = {
  received: "eyes",
  running: "hourglass_flowing_sand",
  completed: "white_check_mark",
  failed: "x",
} as const;

const COMMANDS = ["help", "status", "kill", "meltdown"] as const;
type Command = (typeof COMMANDS)[number];

const MAX_MESSAGE_LENGTH = 4000;

export function registerSlackHandlers(
  app: App,
  taskManager: TaskManager,
): void {
  // Listen to app_mention events
  app.event("app_mention", async ({ event, say, client }) => {
    const text = stripMention(event.text);
    const channelId = event.channel;
    const threadTs = event.thread_ts ?? event.ts; // parent or self
    const isTopLevel = !event.thread_ts;

    // Parse command
    const command = parseCommand(text);

    if (command) {
      await handleCommand(command, {
        channelId,
        threadTs,
        isTopLevel,
        say: (msg: string) =>
          say({ text: msg, thread_ts: threadTs }),
        taskManager,
      });
      return;
    }

    // Task instruction
    await handleTaskInstruction({
      text,
      channelId,
      threadTs,
      messageTs: event.ts,
      client,
      say: (msg: string) =>
        say({ text: msg, thread_ts: threadTs }),
      taskManager,
    });
  });

  // Wire up task events to Slack
  taskManager.on("judgment", async (threadId, result) => {
    await postJudgment(app, threadId, result);
  });

  taskManager.on("stateChange", async (threadId, state) => {
    await updateReaction(app, threadId, state);
  });
}

// --- Command handlers ---

interface CommandContext {
  channelId: string;
  threadTs: string;
  isTopLevel: boolean;
  say: (msg: string) => Promise<unknown>;
  taskManager: TaskManager;
}

async function handleCommand(
  command: Command,
  ctx: CommandContext,
): Promise<void> {
  switch (command) {
    case "help":
      await ctx.say(
        [
          "*Commands:*",
          "`help` - Show this message",
          "`status` - Show running/queued task counts",
          "`kill` - Terminate task in this thread",
          "`meltdown` - Force-kill all tasks on this node",
        ].join("\n"),
      );
      break;

    case "status": {
      const s = ctx.taskManager.status();
      if (s.running === 0 && s.queued === 0) {
        await ctx.say("No active tasks.");
      } else {
        await ctx.say(
          `Running: ${s.running}, Queued: ${s.queued}`,
        );
      }
      break;
    }

    case "kill": {
      if (ctx.isTopLevel) {
        await ctx.say("Use `kill` inside a task thread.");
        return;
      }
      const killed = await ctx.taskManager.kill(ctx.threadTs);
      await ctx.say(killed ? "Task terminated." : "No running task in this thread.");
      break;
    }

    case "meltdown": {
      const count = await ctx.taskManager.meltdown();
      await ctx.say(`Meltdown complete. ${count} task(s) terminated.`);
      break;
    }
  }
}

// --- Task instruction handler ---

interface TaskContext {
  text: string;
  channelId: string;
  threadTs: string;
  messageTs: string;
  client: { reactions: { add: (args: { channel: string; timestamp: string; name: string }) => Promise<unknown> } };
  say: (msg: string) => Promise<unknown>;
  taskManager: TaskManager;
}

async function handleTaskInstruction(ctx: TaskContext): Promise<void> {
  const { text, channelId, threadTs, messageTs, client, say, taskManager } = ctx;

  if (!text.trim()) {
    await say("Please provide a task instruction.");
    return;
  }

  // Add received reaction
  try {
    await client.reactions.add({
      channel: channelId,
      timestamp: messageTs,
      name: REACTIONS.received,
    });
  } catch {
    // Non-critical
  }

  // Check if thread already has a task
  const existing = taskManager.getTask(threadTs);
  if (existing && existing.state === "running") {
    // Additional instruction to running task — not supported in Phase 1
    await say("A task is already running in this thread. Wait for it to finish or use `kill`.");
    return;
  }

  // Submit new task
  const task = taskManager.submit(threadTs, channelId, text);

  if (task.state === "queued") {
    const pos = taskManager.queuePosition(threadTs);
    await say(`Queued (position ${pos}). Waiting for a slot...`);
  }
}

// --- Helpers ---

function stripMention(text: string): string {
  // Remove <@BOTID> pattern
  return text.replace(/<@[A-Z0-9]+>/g, "").trim();
}

function parseCommand(text: string): Command | null {
  const firstToken = text.split(/\s+/)[0]?.toLowerCase();
  if (firstToken && (COMMANDS as readonly string[]).includes(firstToken)) {
    return firstToken as Command;
  }
  return null;
}

/** Post judgment result to Slack thread */
async function postJudgment(
  app: App,
  threadId: string,
  result: JudgmentResult,
): Promise<void> {
  // threadId format: channelId is stored in the task record
  // We need to find the task to get the channelId
  // This is handled by the caller who has access to taskManager

  // For now, we use the app's client directly
  // The threadId is the thread_ts, but we need channelId too
  // This will be wired up through the event system
  if (!result.summary) return;

  let message = result.summary;

  if (result.category === "user_confirmation_needed" && result.options) {
    message += "\n\nChoose:\n" + result.options.map((o, i) => `${i + 1}. ${o}`).join("\n");
  }

  if (result.category === "failed") {
    message += "\n\nRetry?";
  }

  // Truncate if needed
  if (message.length > MAX_MESSAGE_LENGTH) {
    message = message.slice(0, MAX_MESSAGE_LENGTH - 20) + "\n...(truncated)";
  }

  // Note: actual posting requires channelId, which comes from TaskRecord
  // This is coordinated in the integration layer (index.ts)
  console.log(`[slack] judgment for thread ${threadId}: ${result.category}`);
}

/** Update reaction emoji based on state */
async function updateReaction(
  _app: App,
  threadId: string,
  state: string,
): Promise<void> {
  // Reaction updates require the original message ts and channel
  // This coordination happens in the integration layer
  console.log(`[slack] state change for thread ${threadId}: ${state}`);
}
