// Shared type definitions for ClaudeThread

export interface AppConfig {
  slack: {
    botToken: string;
    appToken: string;
  };
  claude: {
    binaryPath: string; // empty = use system PATH
    workingDirectory: string; // empty = use process cwd
    authMethod: "oauth" | "apikey";
    apiKey: string; // used only when authMethod = "apikey"
  };
  runner: {
    maxConcurrent: number;
    killTimeoutMs: number;
    judgmentBufferSize: number; // chars before triggering LLM judgment
    judgmentIntervalMs: number; // min interval between judgment calls
  };
  gui: {
    port: number;
  };
}

export type ProcessState =
  | "queued"
  | "running"
  | "completed"
  | "failed"
  | "killed";

export interface TaskRecord {
  threadId: string;
  channelId: string;
  pid: number | null;
  state: ProcessState;
  prompt: string;
  startedAt: Date | null;
  endedAt: Date | null;
  stdoutBuffer: string;
  stderrBuffer: string;
}

export type JudgmentCategory =
  | "user_confirmation_needed"
  | "completed"
  | "failed"
  | "loop_detected"
  | "in_progress";

export interface JudgmentResult {
  category: JudgmentCategory;
  summary: string;
  options?: string[]; // for user_confirmation_needed
}
